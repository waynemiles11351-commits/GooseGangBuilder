# 零基础 Git + GitHub 云构建 ipa 保姆级教程

> 适用：完全没用过 Git、没有 Mac 的用户。
> 全程图形界面点按，不需要输入任何命令。
> 需要：一台能上网的 **Windows 电脑**（最好）+ 手机。

---

## 第 0 步：解压项目包

1. 下载 `GooseGang-project.zip`
2. Windows 上右键 → **全部解压缩**（或双击打开后点"解压到"）
3. 解压后你会看到一个文件夹，里面有 `README.md`、`docs`、`ios`、`pc_prototype`、`.github` 这几样
4. **记下这个文件夹的位置**（比如在桌面），后面要用

---

## 第 1 步：注册 GitHub 账号（5 分钟）

1. 电脑浏览器打开 **https://github.com**
2. 点右上角 **Sign up**（注册）
3. 依次填写：邮箱 → 密码 → 用户名 → 按提示完成人机验证
4. 注册完成后，去邮箱点 GitHub 发来的**验证邮件**（没有就检查垃圾邮件）
5. 验证成功后，回到 github.com 会自动登录

---

## 第 2 步：安装 GitHub Desktop（图形化工具，替代命令）

1. 浏览器打开 **https://desktop.github.com**
2. 点 **Download for Windows** 下载安装包
3. 双击安装包，一路 **Next → Install** 装完
4. 启动 GitHub Desktop

---

## 第 3 步：登录 GitHub Desktop

1. 打开后点 **Sign in to GitHub.com**
2. 会跳转到浏览器，点 **Authorize desktop**（授权）
3. 回到 GitHub Desktop，显示你的头像和用户名 = 登录成功

---

## 第 4 步：新建仓库并放入项目文件

1. 点菜单 **File → New repository…**
2. 填写弹窗：
   - **Name**：`GooseGang`
   - **Description**：随便写，如"鹅鸭杀身份分析"
   - **Local path**：选一个位置，比如 `桌面`
   - 其他不用动
3. 点 **Create repository**，桌面会出现一个 `GooseGang` 文件夹
4. 打开第 0 步解压出来的项目文件夹，把里面的 **全部内容**（README.md、docs、ios、pc_prototype、.github 这 5 样）**全部复制**，粘贴进桌面的 `GooseGang` 文件夹里
   - ⚠️ 注意：`.github` 是隐藏文件夹，复制时要在项目文件夹里直接全选复制；粘贴后确认 GooseGang 文件夹里能看到它
5. 切回 GitHub Desktop，它会自动显示"检测到新文件"（左侧出现一长串变更列表）

---

## 第 5 步：提交并发布（上传到 GitHub 云端）

1. 看 GitHub Desktop 窗口左下方，有一个 **Summary** 输入框
2. 在里面随便打一句，比如 `first commit`（这是提交说明）
3. 点 **Commit to main**（绿色按钮）
4. 点窗口最上方的 **Publish repository**（发布按钮，也可能显示为 **Publish branch**）
5. 弹窗里 **Keep this code private** 不要勾选（选 Public，免费额度才够），点 **Publish repository**
6. 等几秒提示发布成功，右上角出现 **View on GitHub** → 点它
7. 浏览器会打开你的仓库页面 `https://github.com/你的用户名/GooseGang`

---

## 第 6 步：触发云构建（在 GitHub 云端 Mac 上编译 ipa）

1. 在仓库页面，点顶部菜单 **Actions**（没有就在 Settings → Actions 里把 General 的 Actions 设为 Allowed，再回来）
2. 左侧列表点 **Build IPA**
3. 右侧出现 **Run workflow** 按钮 → 点它 → 再点绿色 **Run workflow** 确认
4. 页面出现一个正在跑的构建任务（黄色圆点 = 进行中），点进去看进度
5. **等 3~5 分钟**，全部步骤变绿（✓）就是成功了

---

## 第 7 步：下载 ipa

1. 构建任务跑完（全绿）后，往下滚动到页面底部 **Artifacts** 区域
2. 点 **GooseGang-ipa** 下载，得到一个 zip
3. 解压后就是 **GooseGang.ipa** ✅ 到手

---

## 第 8 步：安装到 iPhone

未签名 ipa 不能直接装，用 Apple ID 免费签名后安装（7 天有效，到期重签一次）：

**有 Windows 电脑（推荐）：**
1. 电脑安装「**爱思助手**」（官网 aisi.com）
2. 数据线连接 iPhone，手机上信任此电脑
3. 爱思助手 → **应用游戏** 页 → 把 `GooseGang.ipa` 拖进窗口 → 自动签名安装
4. 装好后在 iPhone 上打开；如果提示"未受信任的开发者"：设置 → 通用 → VPN与设备管理 → 找到你的 Apple ID → 点"信任"

**只有 iPhone：**
1. 手机安装「**牛蛙助手**」（官网 niuwa.top 下载）
2. 把 ipa 传到手机（微信/浏览器下载均可），牛蛙助手里导入 → 自签安装

---

## 常见卡点排查

| 问题 | 解决办法 |
|---|---|
| 邮箱验证邮件没收到 | 查垃圾邮件；或重新登录 github.com 点"Resend" |
| Actions 里没有 Build IPA | 确认 `.github/workflows/build-ipa.yml` 已上传（第 4 步复制时别漏 `.github` 文件夹） |
| 构建失败（红叉） | 点进去看哪一步红，截图发我，我来排查 |
| Artifacts 区没东西 | 等构建完全结束（所有步骤绿）再看 |
| 手机上提示"未受信任的开发者" | 设置 → 通用 → VPN与设备管理 → 信任 |

---

## 如果连 Windows 电脑也没有（只有手机）

**好消息：手机也能搞定。** 我已把构建流程改成"手机友好版"——
你只需要 **上传 1 个压缩包** + **创建 1 个文本文件**，剩下的云端自动完成。

### 手机版操作步骤

**1. 注册 GitHub（手机浏览器）**
- 打开 **github.com** → Sign up → 填邮箱/密码/用户名 → 邮箱点验证邮件

**2. 新建仓库**
- 登录后点右上 **+** → **New repository** → Name 填 `GooseGang`
- **Public**（默认，免费额度够）→ 勾选 **Add a README file**（可选）→ **Create repository**

**3. 上传项目压缩包（1 个文件）**
- 进入仓库页 → 点 **Add file** → **Upload files**
- 从手机里选择 `GooseGang-project.zip`（先下载到手机）
- 点 **Commit changes**（提交说明随便填）

**4. 创建构建配置文件（1 个文本文件）**
- 仓库页 → **Add file** → **Create new file**
- **文件名称栏输入**：`.github/workflows/build-ipa.yml`（GitHub 会自动创建文件夹）
- 在下面的大输入框里，**粘贴下面这段内容**（从 `# ===` 开始到文件末尾，全部复制）：

```yaml
# 手机友好版：GitHub Actions 云构建 ipa
# 自动解压 GooseGang-project.zip → 云端 macOS 编译 → 产出 ipa
name: Build IPA

on:
  workflow_dispatch:
  push:
    branches: [main]

jobs:
  build:
    runs-on: macos-14
    steps:
      - uses: actions/checkout@v4
      - name: Unzip project bundle
        run: unzip -q *.zip -d project
      - name: Install XcodeGen
        run: brew install xcodegen
      - name: Generate Xcode project
        working-directory: project/ios
        run: xcodegen generate
      - name: Build app (unsigned)
        working-directory: project/ios
        run: |
          xcodebuild -project GooseGang.xcodeproj -scheme GooseGang \
            -configuration Release -sdk iphoneos -derivedDataPath build \
            CODE_SIGNING_ALLOWED=NO build
      - name: Package IPA
        working-directory: project/ios
        run: |
          APP="build/Build/Products/Release-iphoneos/GooseGang.app"
          test -d "$APP"
          rm -rf ipa_stage && mkdir -p ipa_stage/Payload
          cp -R "$APP" ipa_stage/Payload/
          cd ipa_stage && zip -qry ../GooseGang.ipa Payload
          cd .. && rm -rf ipa_stage
      - name: Upload IPA artifact
        uses: actions/upload-artifact@v4
        with:
          name: GooseGang-ipa
          path: project/ios/GooseGang.ipa
          if-no-files-found: error
```

- 点 **Commit changes** 保存

**5. 触发构建**
- 仓库页点 **Actions** → 左侧 **Build IPA** → **Run workflow** → 绿色按钮
- 等 3~5 分钟，步骤全绿 = 成功

**6. 下载 ipa**
- 构建页底部 **Artifacts** → 点 **GooseGang-ipa** 下载 zip → 解压得 `GooseGang.ipa`

**7. 手机安装（无需电脑）**
- iPhone 装「**牛蛙助手**」（官网 niuwa.top）
- 把 ipa 存到 iPhone（微信传输/浏览器下载都行）→ 牛蛙助手里导入 → 自签安装
- 打开 App 提示"未受信任" → 设置 → 通用 → VPN与设备管理 → 信任

### 手机版常见问题

| 问题 | 解决办法 |
|---|---|
| 上传时找不到 zip | 先点开链接下载 zip 到手机，再用"文件"App 里选择 |
| Actions 里没有 Build IPA | 确认第 4 步文件名完全正确：`.github/workflows/build-ipa.yml`，且内容粘贴完整 |
| 构建红叉 | 点进去看哪一步红，截图发我排查 |
| 下载的 zip 里没有 ipa | 等所有步骤都变绿再下载 |

---

## 如果你有 Windows 电脑（更省事，可选）

上面的手机版同样适用；有电脑也可以用 GitHub Desktop 图形界面，
步骤见本文档前文"零基础 8 步"。
