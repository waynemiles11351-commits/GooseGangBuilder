import Foundation
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

/// 相册视频选择器：用户选择「系统屏幕录制」保存到相册的鹅鸭杀游戏视频。
/// 系统录屏是 iOS 上捕获其他 App 画面的唯一合规途径。
struct VideoPicker: UIViewControllerRepresentable {
    var onPick: (URL) -> Void
    var onCancel: () -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .videos
        config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: VideoPicker

        init(_ parent: VideoPicker) { self.parent = parent }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true) {
                guard let item = results.first else {
                    self.parent.onCancel()
                    return
                }
                let provider = item.itemProvider
                guard provider.hasItemConformingToTypeIdentifier(UTType.movie.identifier) else {
                    self.parent.onCancel()
                    return
                }
                // 将所选视频复制到 App 沙盒临时目录，便于 AVAssetReader 读取
                provider.loadFileRepresentation(forTypeIdentifier: UTType.movie.identifier) { url, error in
                    guard let url, error == nil else {
                        DispatchQueue.main.async { self.parent.onCancel() }
                        return
                    }
                    let local = FileManager.default.temporaryDirectory
                        .appendingPathComponent(UUID().uuidString)
                        .appendingPathExtension(url.pathExtension.isEmpty ? "mov" : url.pathExtension)
                    do {
                        if FileManager.default.fileExists(atPath: local.path) {
                            try FileManager.default.removeItem(at: local)
                        }
                        try FileManager.default.copyItem(at: url, to: local)
                        DispatchQueue.main.async { self.parent.onPick(local) }
                    } catch {
                        DispatchQueue.main.async { self.parent.onCancel() }
                    }
                }
            }
        }
    }
}
