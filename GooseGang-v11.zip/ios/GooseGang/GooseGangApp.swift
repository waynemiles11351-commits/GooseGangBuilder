import SwiftUI

@main
struct GooseGangApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}
