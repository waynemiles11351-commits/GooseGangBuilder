import SwiftUI

/// 单个玩家的详情：脚程轨迹图 + 行为特征 + 身份概率。
struct PlayerDetailView: View {
    let engine: AnalysisEngine
    let playerName: String

    private var player: Player? {
        engine.players.first { $0.id == playerName }
    }

    var body: some View {
        if let player {
            ScrollView {
                VStack(spacing: 16) {
                    scoreCard(player)
                    if player.trajectory.count > 1 {
                        trajectoryCard(player)
                    }
                    featureCard(player)
                    roleHint(player)
                }
                .padding()
            }
            .navigationTitle(player.id)
            .navigationBarTitleDisplayMode(.inline)
        } else {
            Text("玩家已离线").foregroundColor(.secondary)
        }
    }

    private func scoreCard(_ player: Player) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("身份概率")
                .font(.headline)
            let probs = player.scores.probabilities
            ForEach(GameIdentity.allCases) { identity in
                HStack {
                    Text(identity.rawValue)
                        .font(.callout)
                        .frame(width: 44, alignment: .leading)
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.secondary.opacity(0.15))
                            Capsule().fill(Color(hex: identity.colorHex))
                                .frame(width: geo.size.width * CGFloat(probs[identity] ?? 0))
                        }
                    }
                    .frame(height: 12)
                    Text("\(Int((probs[identity] ?? 0) * 100))%")
                        .font(.caption.monospacedDigit())
                        .frame(width: 48, alignment: .trailing)
                }
            }
            Text("当前判断：\(player.dominantIdentity.rawValue)（\(Int(player.dominantProbability * 100))%）")
                .font(.callout.bold())
                .foregroundColor(Color(hex: player.dominantIdentity.colorHex))
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
    }

    private func trajectoryCard(_ player: Player) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("脚程轨迹")
                .font(.headline)
            TrajectoryMapView(points: player.trajectory.map { CGPoint(x: CGFloat($0.x), y: CGFloat($0.y)) })
                .frame(height: 220)
                .background(RoundedRectangle(cornerRadius: 12).fill(Color(.systemBackground)))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.secondary.opacity(0.3)))
            HStack {
                Text("路径长度 \(String(format: "%.2f", player.totalPathLength))")
                Spacer()
                Text("平均速度 \(String(format: "%.3f", player.averageSpeed))/s")
                Spacer()
                Text("蜿蜒度 \(String(format: "%.0f%%", player.meandering * 100))")
            }
            .font(.caption)
            .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
    }

    private func featureCard(_ player: Player) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("行为特征（证据）")
                .font(.headline)
            HStack {
                StatCell(title: "任务停留", value: "\(Int(player.taskDwellSeconds))s", tint: .green)
                StatCell(title: "尾随次数", value: "\(player.tailCount)", tint: .orange)
                StatCell(title: "靠近尸体", value: "\(player.corpseCloseEvents)", tint: .red)
                StatCell(title: "帧数", value: "\(player.framesTracked)", tint: .blue)
            }
            Text("说明：任务停留、尾随、尸体接近都是身份推理的证据，权重可在源码 IdentityModel 中调整。")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
    }

    private func roleHint(_ player: Player) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("可能的角色")
                .font(.headline)
            Text(player.dominantIdentity.exampleRoles.joined(separator: " · "))
                .font(.callout)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
    }
}

/// 脚程轨迹地图：把归一化轨迹画在画布上。
struct TrajectoryMapView: View {
    let points: [CGPoint]

    var body: some View {
        Canvas { context, size in
            guard points.count > 1 else { return }
            let scaleX = size.width
            let scaleY = size.height

            // 轨迹线
            var path = Path()
            path.move(to: CGPoint(x: points[0].x * scaleX, y: points[0].y * scaleY))
            for p in points.dropFirst() {
                path.addLine(to: CGPoint(x: p.x * scaleX, y: p.y * scaleY))
            }
            context.stroke(path, with: .color(.blue.opacity(0.7)), lineWidth: 2)

            // 起点/终点
            let start = CGPoint(x: points[0].x * scaleX, y: points[0].y * scaleY)
            let end = CGPoint(x: points.last!.x * scaleX, y: points.last!.y * scaleY)
            context.fill(Path(ellipseIn: CGRect(x: start.x - 4, y: start.y - 4, width: 8, height: 8)),
                         with: .color(.green))
            context.fill(Path(ellipseIn: CGRect(x: end.x - 5, y: end.y - 5, width: 10, height: 10)),
                         with: .color(.red))

            context.draw(Text("起").font(.caption2), at: CGPoint(x: start.x + 8, y: start.y - 12))
            context.draw(Text("终").font(.caption2), at: CGPoint(x: end.x + 8, y: end.y - 12))
        }
    }
}

/// 统计小格
struct StatCell: View {
    let title: String
    let value: String
    let tint: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.headline)
                .foregroundColor(tint)
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color(.systemBackground)))
    }
}
