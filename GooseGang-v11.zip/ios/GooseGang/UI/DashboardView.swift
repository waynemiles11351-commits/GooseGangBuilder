import SwiftUI
import UIKit

/// 主仪表盘：选择录屏 → 分析 → 实时展示每个玩家的身份概率。
struct DashboardView: View {
    @StateObject private var engine = AnalysisEngine()
    @State private var showPicker = false
    @State private var selectedVideoURL: URL?

    var body: some View {
        NavigationView {
            VStack(spacing: 12) {
                header
                mostSuspiciousBanner
                phaseIndicator
                if engine.players.isEmpty {
                    emptyHint
                } else {
                    playerList
                }
            }
            .padding()
            .navigationTitle("鹅鸭杀·身份分析")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showPicker = true }) {
                        Label("选择录屏", systemImage: "video.badge.plus")
                    }
                }
            }
            .sheet(isPresented: $showPicker) {
                VideoPicker(onPick: { url in
                    selectedVideoURL = url
                    engine.analyze(url: url)
                }, onCancel: {})
            }
        }
        .navigationViewStyle(.stack)
    }

    // MARK: - 组件

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("游戏阶段：\(engine.gamePhase.label)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text("已追踪玩家 \(engine.players.count) 人 · 尸体事件 \(engine.corpseEvents.count) 起")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Spacer()
            if case .analyzing = engine.phase {
                Button("停止") { engine.stop() }
                    .buttonStyle(.bordered)
            }
        }
    }

    /// 当前最可疑玩家提醒（按可疑度取最高者）
    @ViewBuilder
    private var mostSuspiciousBanner: some View {
        if let top = engine.players.max(by: { $0.suspicionScore < $1.suspicionScore }),
           top.suspicionScore > 0.45 {
            HStack(spacing: 8) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
                VStack(alignment: .leading, spacing: 1) {
                    Text("最可疑：\(top.id)（鸭 \(Int((top.scores.probabilities[.duck] ?? 0) * 100))% · \(top.behaviorTag.rawValue)）")
                        .font(.footnote.bold())
                    Text("可疑度 \(Int(top.suspicionScore * 100)) / 100")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            .padding(10)
            .background(Color.orange.opacity(0.12))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
    }

    @ViewBuilder
    private var phaseIndicator: some View {
        switch engine.phase {
        case .idle:
            Label("选择一个录屏视频开始分析", systemImage: "hand.tap")
                .font(.callout)
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        case .loadingVideo:
            HStack { ProgressView(); Text("正在载入视频…") }
                .font(.callout)
        case .analyzing(let progress):
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    ProgressView(value: progress)
                    Text("\(Int(progress * 100))%")
                        .font(.caption.monospacedDigit())
                }
                Text("正在逐帧分析画面（OCR 识别玩家、追踪脚程、推理身份）…")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        case .done:
            Label("分析完成", systemImage: "checkmark.circle.fill")
                .foregroundColor(.green)
        case .failed(let msg):
            Label(msg, systemImage: "exclamationmark.triangle.fill")
                .foregroundColor(.red)
        }
    }

    private var emptyHint: some View {
        VStack(spacing: 12) {
            Image(systemName: "bird")
                .font(.system(size: 44))
                .foregroundColor(.secondary)
            Text("分析后，这里会显示每位玩家的\n身份概率与脚程轨迹")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var playerList: some View {
        List {
            ForEach(engine.players.sorted { $0.suspicionScore > $1.suspicionScore }) { player in
                NavigationLink(destination: PlayerDetailView(engine: engine, playerName: player.id)) {
                    PlayerRow(player: player)
                }
            }
        }
        .listStyle(.insetGrouped)
    }
}

/// 玩家行：名字 + 三阵营概率条 + 主导身份。
struct PlayerRow: View {
    let player: Player

    private var probs: [GameIdentity: Double] { player.scores.probabilities }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(player.id)
                    .font(.headline)
                    .lineLimit(1)
                Text(player.behaviorTag.rawValue)
                    .font(.caption2.bold())
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(behaviorColor.opacity(0.15))
                    .foregroundColor(behaviorColor)
                    .clipShape(Capsule())
                Spacer()
                Text("\(player.dominantIdentity.rawValue) \(Int(player.dominantProbability * 100))%")
                    .font(.subheadline.bold())
                    .foregroundColor(Color(hex: player.dominantIdentity.colorHex))
            }
            HStack(spacing: 8) {
                IdentityBar(identity: .goose, value: probs[.goose] ?? 0)
                IdentityBar(identity: .duck, value: probs[.duck] ?? 0)
                IdentityBar(identity: .neutral, value: probs[.neutral] ?? 0)
            }
            .frame(height: 8)
            Text("脚程：\(String(format: "%.1f", player.totalPathLength)) · 速度 \(String(format: "%.2f", player.averageSpeed))/s · 尾随 \(player.tailCount) 次 · 任务停留 \(Int(player.taskDwellSeconds))s")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }

    /// 行为标签配色：尾随/绕圈=红（鸭倾向），任务停留=绿（鹅倾向），围观=橙，正常=灰
    private var behaviorColor: Color {
        switch player.behaviorTag {
        case .tailing: return .red
        case .wandering: return .orange
        case .dwelling: return .green
        case .corpse: return .orange
        case .normal: return .gray
        }
    }
}

/// 单阵营概率条
struct IdentityBar: View {
    let identity: GameIdentity
    let value: Double

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.secondary.opacity(0.15))
                Capsule().fill(Color(hex: identity.colorHex))
                    .frame(width: geo.size.width * CGFloat(value))
            }
        }
        .accessibilityLabel("\(identity.rawValue) \(Int(value * 100))%")
    }
}

extension Color {
    /// 从 hex 字符串初始化（如 "#4CAF50"）
    init(hex: String) {
        let h = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: h).scanHexInt64(&int)
        let r = Double((int >> 16) & 0xFF) / 255
        let g = Double((int >> 8) & 0xFF) / 255
        let b = Double(int & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
}
