import CoreGraphics
import Foundation

/// 多目标追踪器：以「游戏内唯一名字」为稳定 ID 维护玩家状态。
/// 每帧将检测结果合并进各玩家的轨迹与统计。
final class PlayerTracker {
    private(set) var players: [String: Player] = [:]

    /// 更新一帧的玩家状态。
    func update(observation: FrameObservation, frameSize: CGSize) {
        for det in observation.players {
            // OCR 抖动合并：同一玩家名字的识别变体归并为一个 ID
            var name = det.name
            if players[name] == nil, let similar = findSimilar(to: name) {
                name = similar
            }
            // 名字标签框可能在画面上半部（镜头内名字与身体分离），合并取身体中心
            let pos = CGPoint(x: det.bodyBox.midX, y: det.bodyBox.midY)
            var player = players[name] ?? Player(id: name)
            defer { players[name] = player }

            let dt: TimeInterval
            if let last = player.lastPosition, player.framesTracked > 0 {
                // 归一化坐标下的欧氏距离
                let dist = hypot(Double(pos.x - last.x), Double(pos.y - last.y))
                dt = observation.time - player.lastSeen
                if dt > 0 {
                    let speed = dist / dt
                    player.speedSamples.append(speed)
                    if player.speedSamples.count > 200 {
                        player.speedSamples.removeFirst(player.speedSamples.count - 200)
                    }
                }
                player.totalPathLength += dist
                player.netDisplacement = hypot(Double(pos.x - (player.trajectory.first?.x ?? pos.x)),
                                               Double(pos.y - (player.trajectory.first?.y ?? pos.y)))
            }
            player.lastPosition = pos
            player.lastSeen = observation.time
            player.framesTracked += 1
            player.trajectory.append(TrajectoryPoint(time: observation.time, x: Double(pos.x), y: Double(pos.y)))
            if player.trajectory.count > 1200 {
                player.trajectory.removeFirst(player.trajectory.count - 1200)
            }
        }
    }

    /// 所有当前在线的玩家（按最后出现时间排序）
    var activePlayers: [Player] {
        players.values.filter { $0.framesTracked > 0 }
            .sorted { $0.lastSeen > $1.lastSeen }
    }

    /// 删除长时间未出现的玩家（玩家可能死亡/离开）
    func prune(olderThan time: TimeInterval) {
        players = players.filter { $0.value.lastSeen >= time }
    }

    /// 清空全部状态（新一轮分析）
    func reset() {
        players.removeAll()
    }

    /// OCR 抖动合并：与已有玩家名编辑距离 ≤ 2 且首字符相同 → 视为同一玩家
    private func findSimilar(to name: String) -> String? {
        for existing in players.keys where existing.first == name.first {
            if Self.editDistance(existing, name) <= 2 {
                return existing
            }
        }
        return nil
    }

    private static func editDistance(_ a: String, _ b: String) -> Int {
        let charsA = Array(a)
        let charsB = Array(b)
        guard abs(charsA.count - charsB.count) <= 2 else { return 9 }
        var dp = Array(0...charsB.count)
        for (i, ca) in charsA.enumerated() {
            var prev = dp[0]
            dp[0] = i + 1
            for (j, cb) in charsB.enumerated() {
                let cur = dp[j + 1]
                let insert = dp[j + 1] + 1
                let delete = dp[j] + 1
                let replace = prev + (ca == cb ? 0 : 1)
                dp[j + 1] = min(insert, delete, replace)
                prev = cur
            }
        }
        return dp[charsB.count]
    }
}
