import CoreGraphics
import Foundation

/// 脚程分析引擎：从轨迹中提取行为特征。
/// 这些特征后续进入身份概率推理：
///  - 任务停留（鹅行为）
///  - 高速绕路（鸭行为）
///  - 尾随他人（鸭行为）
///  - 尸体附近短现即离（凶手逃离 / 案发在场）
///  - 尸体旁围观（鹅/中立行为）
final class TrajectoryEngine {

    /// 判定“疑似做任务”：玩家在一段时间内几乎静止。
    /// 鹅做任务时站在任务点不动，是鹅阵营强信号。
    static func taskDwellSeconds(of player: Player, window: Int = 30) -> Double {
        let traj = player.trajectory
        guard traj.count >= window else { return 0 }
        let recent = traj.suffix(window)
        guard let first = recent.first, let last = recent.last else { return 0 }
        let span = last.time - first.time
        guard span > 0 else { return 0 }
        // 窗口内位移 < 1.5% 画面宽度，视为静止
        let moved = hypot(last.x - first.x, last.y - first.y)
        if moved < 0.015 {
            return span
        }
        return 0
    }

    /// 判断两玩家是否处于“尾随”关系：
    /// 持续 N 秒彼此距离 < 阈值，且相对位移方向一致。
    static func isTail(leader: Player, follower: Player, threshold: Double = 0.06, window: Int = 20) -> Bool {
        let a = leader.trajectory.suffix(window)
        let b = follower.trajectory.suffix(window)
        let n = min(a.count, b.count)
        guard n >= 8 else { return false }

        // 同步取最后 n 个点（时间未必对齐，按索引近似）
        let aslice = Array(a.suffix(n))
        let bslice = Array(b.suffix(n))

        var closeFrames = 0
        for i in stride(from: 0, to: n, by: 2) {
            let dx = aslice[i].x - bslice[i].x
            let dy = aslice[i].y - bslice[i].y
            if hypot(dx, dy) < threshold { closeFrames += 1 }
        }
        let closeRatio = Double(closeFrames) / Double(max(1, (n + 1) / 2))
        guard closeRatio > 0.6 else { return false }

        // 方向一致性：两者位移向量夹角小
        guard n >= 16 else { return false }
        let va = CGVector(dx: CGFloat(aslice[n-1].x - aslice[n-9].x), dy: CGFloat(aslice[n-1].y - aslice[n-9].y))
        let vb = CGVector(dx: CGFloat(bslice[n-1].x - bslice[n-9].x), dy: CGFloat(bslice[n-1].y - bslice[n-9].y))
        let la = hypot(va.dx, va.dy), lb = hypot(vb.dx, vb.dy)
        guard la > 0.005, lb > 0.005 else { return false }
        let dot = (va.dx * vb.dx + va.dy * vb.dy) / (la * lb)
        return dot > 0.5
    }

    /// 计算某玩家距所有尸体中最近的距离
    static func distance(to corpse: CGPoint, player: Player) -> Double? {
        guard let pos = player.lastPosition else { return nil }
        return hypot(Double(pos.x - corpse.x), Double(pos.y - corpse.y))
    }

    /// 尸体事件特征：记录案发时在场玩家、以及后续靠近/远离行为。
    struct CorpseFeatureResult {
        var witnesses: [String] = []        // 尸体出现瞬间在场的玩家
        var mourners: [String] = []         // 之后在尸体旁停留的玩家
        var fleers: [String] = []           // 尸体出现后快速远离的玩家
    }

    static func corpseFeatures(corpse: CorpseEvent, players: [String: Player], frameSize: CGSize) -> CorpseFeatureResult {
        var result = CorpseFeatureResult()
        for (name, player) in players {
            guard let pos = player.lastPosition else { continue }
            let dist = hypot(Double(pos.x - corpse.position.x), Double(pos.y - corpse.position.y))
            if dist < 0.10 {
                result.witnesses.append(name)
            }
            // 案发后 5 秒内仍靠近尸体 → 围观
            if player.lastSeen - corpse.time < 5.0 && dist < 0.10 {
                result.mourners.append(name)
            }
        }
        return result
    }
}
